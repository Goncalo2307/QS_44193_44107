package com.eduscrum.qs.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduscrumBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduscrumBackendApplication.class, args);
	}

}
