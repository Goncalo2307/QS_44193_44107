package com.eduscrum.qs.backend.domain.enums;

public enum ScrumRoleType {
    SCRUM_MASTER,
    PRODUCT_OWNER,
    DEVELOPER
}
