package com.eduscrum.qs.backend.domain.enums;

public enum TaskStatus {
    TO_DO,
    IN_PROGRESS,
    DONE
}
