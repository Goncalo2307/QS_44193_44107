package com.eduscrum.qs.backend.domain.enums;

public enum UserRoleType {
    ROLE_STUDENT,
    ROLE_TEACHER,
    ROLE_ADMIN
}
