package com.eduscrum.qs.backend.service;

import com.eduscrum.qs.backend.domain.model.AcademicCourse;

import java.util.List;

public interface AcademicCourseService {
    AcademicCourse create(AcademicCourse course);
    AcademicCourse getById(Long id);
    List<AcademicCourse> listAll();
    AcademicCourse update(Long id, AcademicCourse updated);
    void delete(Long id);
}
