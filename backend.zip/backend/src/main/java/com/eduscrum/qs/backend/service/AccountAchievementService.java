package com.eduscrum.qs.backend.service;

import com.eduscrum.qs.backend.domain.model.AccountAchievement;

import java.util.List;

public interface AccountAchievementService {
    AccountAchievement create(AccountAchievement accountAchievement);
    AccountAchievement getById(Long id);
    List<AccountAchievement> listAll();
    List<AccountAchievement> listByAccount(Long accountId);
    void delete(Long id);
}
