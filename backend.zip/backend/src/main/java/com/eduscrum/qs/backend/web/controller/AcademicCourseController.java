package com.eduscrum.qs.backend.web.controller;

import com.eduscrum.qs.backend.domain.model.AcademicCourse;
import com.eduscrum.qs.backend.domain.model.Account;
import com.eduscrum.qs.backend.exception.ResourceNotFoundException;
import com.eduscrum.qs.backend.repository.AcademicCourseRepository;
import com.eduscrum.qs.backend.repository.AccountRepository;
import com.eduscrum.qs.backend.web.dto.request.CourseRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class AcademicCourseController {

    private final AcademicCourseRepository courseRepo;
    private final AccountRepository accountRepo;

    public AcademicCourseController(AcademicCourseRepository courseRepo, AccountRepository accountRepo) {
        this.courseRepo = courseRepo;
        this.accountRepo = accountRepo;
    }

    @GetMapping
    public List<AcademicCourse> listAll() {
        return courseRepo.findAll();
    }

    @GetMapping("/{id}")
    public AcademicCourse getById(@PathVariable Long id) {
        return courseRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AcademicCourse not found: " + id));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public AcademicCourse create(@Valid @RequestBody CourseRequest req) {
        AcademicCourse course = new AcademicCourse();
        course.setName(req.name());
        course.setDescription(req.description());

        if (req.teacherAccountId() != null) {
            Account teacher = accountRepo.findById(req.teacherAccountId())
                    .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + req.teacherAccountId()));
            course.setTeacher(teacher);
        } else {
            course.setTeacher(null);
        }

        return courseRepo.save(course);
    }

    @PutMapping("/{id}")
    public AcademicCourse update(@PathVariable Long id, @Valid @RequestBody CourseRequest req) {
        AcademicCourse course = getById(id);

        course.setName(req.name());
        course.setDescription(req.description());

        if (req.teacherAccountId() != null) {
            Account teacher = accountRepo.findById(req.teacherAccountId())
                    .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + req.teacherAccountId()));
            course.setTeacher(teacher);
        } else {
            course.setTeacher(null);
        }

        return courseRepo.save(course);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        courseRepo.delete(getById(id));
    }
}
