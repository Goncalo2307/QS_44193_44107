package com.eduscrum.qs.backend.web.controller;

import com.eduscrum.qs.backend.domain.model.*;
import com.eduscrum.qs.backend.exception.ConflictException;
import com.eduscrum.qs.backend.exception.ResourceNotFoundException;
import com.eduscrum.qs.backend.repository.*;
import com.eduscrum.qs.backend.web.dto.request.AchievementRequest;
import com.eduscrum.qs.backend.web.dto.request.GrantAchievementRequest;
import com.eduscrum.qs.backend.web.dto.response.LeaderboardEntryResponse;
import com.eduscrum.qs.backend.web.dto.response.TeamLeaderboardEntryResponse;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/achievements")
public class AchievementController {

    private final AchievementRepository achievementRepo;
    private final AccountRepository accountRepo;
    private final AccountAchievementRepository accountAchievementRepo;
    private final TeamAssignmentRepository teamAssignmentRepo;

    public AchievementController(
            AchievementRepository achievementRepo,
            AccountRepository accountRepo,
            AccountAchievementRepository accountAchievementRepo,
            TeamAssignmentRepository teamAssignmentRepo
    ) {
        this.achievementRepo = achievementRepo;
        this.accountRepo = accountRepo;
        this.accountAchievementRepo = accountAchievementRepo;
        this.teamAssignmentRepo = teamAssignmentRepo;
    }

    // -------------------------
    // CRUD Achievement
    // -------------------------

    @GetMapping
    public List<Achievement> listAll() {
        return achievementRepo.findAll();
    }

    @GetMapping("/{id}")
    public Achievement getById(@PathVariable Long id) {
        return achievementRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Achievement not found: " + id));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Achievement create(@Valid @RequestBody AchievementRequest req) {
        Achievement a = new Achievement();

        // domain.zip: Achievement tem "name" (não "title")
        a.setName(req.title()); // podes manter o DTO como "title" e mapear para name
        a.setDescription(req.description());
        a.setPoints(req.points());

        return achievementRepo.save(a);
    }

    @PutMapping("/{id}")
    public Achievement update(@PathVariable Long id, @Valid @RequestBody AchievementRequest req) {
        Achievement a = getById(id);

        a.setName(req.title()); // idem
        a.setDescription(req.description());
        a.setPoints(req.points());

        return achievementRepo.save(a);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        achievementRepo.delete(getById(id));
    }

    // -------------------------
    // Grant Achievement to Account
    // -------------------------

    @PostMapping("/grant")
    @ResponseStatus(HttpStatus.CREATED)
    public AccountAchievement grant(@Valid @RequestBody GrantAchievementRequest req) {
        Account acc = accountRepo.findById(req.accountId())
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + req.accountId()));

        Achievement ach = achievementRepo.findById(req.achievementId())
                .orElseThrow(() -> new ResourceNotFoundException("Achievement not found: " + req.achievementId()));

        // evita duplicados sem depender de método custom no repo
        boolean exists = accountAchievementRepo.findAll().stream()
                .anyMatch(x -> x.getAccount() != null && x.getAchievement() != null
                        && req.accountId().equals(x.getAccount().getId())
                        && req.achievementId().equals(x.getAchievement().getId()));

        if (exists) {
            throw new ConflictException("Achievement already granted to this account.");
        }

        AccountAchievement aa = new AccountAchievement();
        aa.setAccount(acc);
        aa.setAchievement(ach);

        // domain.zip: AccountAchievement tem "assignedAt" (não "grantedBy"/"note")
        aa.setAssignedAt(LocalDateTime.now());

        return accountAchievementRepo.save(aa);
    }

    // -------------------------
    // Leaderboards
    // -------------------------

    @GetMapping("/leaderboard")
    public List<LeaderboardEntryResponse> leaderboard() {
        List<AccountAchievement> all = accountAchievementRepo.findAll();

        Map<Long, List<AccountAchievement>> byAccount = all.stream()
                .filter(x -> x.getAccount() != null)
                .collect(Collectors.groupingBy(x -> x.getAccount().getId()));

        List<LeaderboardEntryResponse> out = new ArrayList<>();

        for (var entry : byAccount.entrySet()) {
            Long accountId = entry.getKey();
            List<AccountAchievement> awards = entry.getValue();

            String name = awards.get(0).getAccount().getName();
            long totalAchievements = awards.size();
            int totalPoints = awards.stream()
                    .map(AccountAchievement::getAchievement)
                    .filter(Objects::nonNull)
                    .mapToInt(a -> a.getPoints() == null ? 0 : a.getPoints())
                    .sum();

            out.add(new LeaderboardEntryResponse(accountId, name, totalAchievements, totalPoints));
        }

        out.sort(Comparator.comparingInt(LeaderboardEntryResponse::totalPoints).reversed());
        return out;
    }

    @GetMapping("/team-leaderboard/{teamId}")
    public List<TeamLeaderboardEntryResponse> teamLeaderboard(@PathVariable Long teamId) {
        // Mantém o método que já estás a usar no teu repo
        List<TeamAssignment> members = teamAssignmentRepo.findByTeamId(teamId);
        if (members.isEmpty()) return List.of();

        Set<Long> memberIds = members.stream()
                .map(m -> m.getAccount().getId())
                .collect(Collectors.toSet());

        List<AccountAchievement> allAwards = accountAchievementRepo.findAll().stream()
                .filter(x -> x.getAccount() != null && memberIds.contains(x.getAccount().getId()))
                .toList();

        Map<Long, List<AccountAchievement>> byAccount = allAwards.stream()
                .collect(Collectors.groupingBy(x -> x.getAccount().getId()));

        List<TeamLeaderboardEntryResponse> out = new ArrayList<>();

        for (TeamAssignment m : members) {
            Long accountId = m.getAccount().getId();
            String name = m.getAccount().getName();

            List<AccountAchievement> awards = byAccount.getOrDefault(accountId, List.of());
            long totalAchievements = awards.size();
            int totalPoints = awards.stream()
                    .map(AccountAchievement::getAchievement)
                    .filter(Objects::nonNull)
                    .mapToInt(a -> a.getPoints() == null ? 0 : a.getPoints())
                    .sum();

            out.add(new TeamLeaderboardEntryResponse(
                    teamId,
                    accountId,
                    name,
                    m.getScrumRole(),
                    totalAchievements,
                    totalPoints
            ));
        }

        out.sort(Comparator.comparingInt(TeamLeaderboardEntryResponse::totalPoints).reversed());
        return out;
    }
}
