package com.eduscrum.qs.backend.web.controller;

import com.eduscrum.qs.backend.domain.model.AcademicCourse;
import com.eduscrum.qs.backend.domain.model.ProjectWorkspace;
import com.eduscrum.qs.backend.exception.ResourceNotFoundException;
import com.eduscrum.qs.backend.repository.AcademicCourseRepository;
import com.eduscrum.qs.backend.repository.ProjectWorkspaceRepository;
import com.eduscrum.qs.backend.web.dto.request.WorkspaceRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/workspaces")
public class ProjectWorkspaceController {

    private final ProjectWorkspaceRepository workspaceRepo;
    private final AcademicCourseRepository courseRepo;

    public ProjectWorkspaceController(ProjectWorkspaceRepository workspaceRepo, AcademicCourseRepository courseRepo) {
        this.workspaceRepo = workspaceRepo;
        this.courseRepo = courseRepo;
    }

    @GetMapping
    public List<ProjectWorkspace> listAll(@RequestParam(required = false) Long courseId) {
        List<ProjectWorkspace> all = workspaceRepo.findAll();
        if (courseId == null) return all;

        return all.stream()
                .filter(w -> w.getCourse() != null && courseId.equals(w.getCourse().getId()))
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ProjectWorkspace getById(@PathVariable Long id) {
        return workspaceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ProjectWorkspace not found: " + id));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProjectWorkspace create(@Valid @RequestBody WorkspaceRequest req) {
        AcademicCourse course = courseRepo.findById(req.courseId())
                .orElseThrow(() -> new ResourceNotFoundException("AcademicCourse not found: " + req.courseId()));

        ProjectWorkspace ws = new ProjectWorkspace();
        ws.setName(req.name());
        ws.setDescription(req.description());
        ws.setCourse(course);

        return workspaceRepo.save(ws);
    }

    @PutMapping("/{id}")
    public ProjectWorkspace update(@PathVariable Long id, @Valid @RequestBody WorkspaceRequest req) {
        ProjectWorkspace ws = getById(id);

        AcademicCourse course = courseRepo.findById(req.courseId())
                .orElseThrow(() -> new ResourceNotFoundException("AcademicCourse not found: " + req.courseId()));

        ws.setName(req.name());
        ws.setDescription(req.description());
        ws.setCourse(course);

        return workspaceRepo.save(ws);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        workspaceRepo.delete(getById(id));
    }
}
