package com.eduscrum.qs.backend.web.controller;

import com.eduscrum.qs.backend.domain.enums.ScrumRoleType;
import com.eduscrum.qs.backend.domain.model.Account;
import com.eduscrum.qs.backend.domain.model.ProjectWorkspace;
import com.eduscrum.qs.backend.domain.model.ScrumTeam;
import com.eduscrum.qs.backend.domain.model.TeamAssignment;
import com.eduscrum.qs.backend.exception.ConflictException;
import com.eduscrum.qs.backend.exception.ResourceNotFoundException;
import com.eduscrum.qs.backend.repository.AccountRepository;
import com.eduscrum.qs.backend.repository.ProjectWorkspaceRepository;
import com.eduscrum.qs.backend.repository.ScrumTeamRepository;
import com.eduscrum.qs.backend.repository.TeamAssignmentRepository;
import com.eduscrum.qs.backend.web.dto.request.TeamMemberRequest;
import com.eduscrum.qs.backend.web.dto.request.TeamRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/teams")
public class ScrumTeamController {

    private final ScrumTeamRepository teamRepo;
    private final ProjectWorkspaceRepository workspaceRepo;
    private final AccountRepository accountRepo;
    private final TeamAssignmentRepository assignmentRepo;

    public ScrumTeamController(
            ScrumTeamRepository teamRepo,
            ProjectWorkspaceRepository workspaceRepo,
            AccountRepository accountRepo,
            TeamAssignmentRepository assignmentRepo
    ) {
        this.teamRepo = teamRepo;
        this.workspaceRepo = workspaceRepo;
        this.accountRepo = accountRepo;
        this.assignmentRepo = assignmentRepo;
    }

    @GetMapping
    public List<ScrumTeam> listAll(@RequestParam(required = false) Long projectId) {
        List<ScrumTeam> all = teamRepo.findAll();
        if (projectId == null) return all;

        return all.stream()
                .filter(t -> t.getProject() != null && projectId.equals(t.getProject().getId()))
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ScrumTeam getById(@PathVariable Long id) {
        return teamRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ScrumTeam not found: " + id));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ScrumTeam create(@Valid @RequestBody TeamRequest req) {
        ProjectWorkspace project = workspaceRepo.findById(req.projectId())
                .orElseThrow(() -> new ResourceNotFoundException("ProjectWorkspace not found: " + req.projectId()));

        ScrumTeam team = new ScrumTeam();
        team.setName(req.name());
        team.setProject(project);

        return teamRepo.save(team);
    }

    @PutMapping("/{id}")
    public ScrumTeam update(@PathVariable Long id, @Valid @RequestBody TeamRequest req) {
        ScrumTeam team = getById(id);

        ProjectWorkspace project = workspaceRepo.findById(req.projectId())
                .orElseThrow(() -> new ResourceNotFoundException("ProjectWorkspace not found: " + req.projectId()));

        team.setName(req.name());
        team.setProject(project);

        return teamRepo.save(team);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        teamRepo.delete(getById(id));
    }

    // ---------- MEMBERS (TeamAssignment) ----------

    @GetMapping("/{teamId}/members")
    public List<TeamAssignment> listMembers(@PathVariable Long teamId) {
        // Se não tiveres este método, filtra por findAll()
        return assignmentRepo.findByTeamId(teamId);
    }

    @PostMapping("/{teamId}/members")
    @ResponseStatus(HttpStatus.CREATED)
    public TeamAssignment addMember(@PathVariable Long teamId, @Valid @RequestBody TeamMemberRequest req) {
        ScrumTeam team = getById(teamId);

        Account account = accountRepo.findById(req.accountId())
                .orElseThrow(() -> new ResourceNotFoundException("Account not found: " + req.accountId()));

        if (assignmentRepo.findByTeamIdAndAccountId(teamId, req.accountId()).isPresent()) {
            throw new ConflictException("Account already assigned to this team.");
        }

        TeamAssignment a = new TeamAssignment();
        a.setTeam(team);
        a.setAccount(account);
        a.setScrumRole(req.scrumRole() == null ? ScrumRoleType.DEVELOPER : req.scrumRole());

        return assignmentRepo.save(a);
    }

    @DeleteMapping("/{teamId}/members/{accountId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removeMember(@PathVariable Long teamId, @PathVariable Long accountId) {
        TeamAssignment a = assignmentRepo.findByTeamIdAndAccountId(teamId, accountId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "TeamAssignment not found for team=" + teamId + " account=" + accountId
                ));
        assignmentRepo.delete(a);
    }
}
