package com.eduscrum.qs.backend.web.controller;

import com.eduscrum.qs.backend.domain.model.ProjectWorkspace;
import com.eduscrum.qs.backend.domain.model.Sprint;
import com.eduscrum.qs.backend.exception.ResourceNotFoundException;
import com.eduscrum.qs.backend.repository.ProjectWorkspaceRepository;
import com.eduscrum.qs.backend.repository.SprintRepository;
import com.eduscrum.qs.backend.web.dto.request.SprintRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/sprints")
public class SprintController {

    private final SprintRepository sprintRepo;
    private final ProjectWorkspaceRepository projectRepo;

    public SprintController(SprintRepository sprintRepo, ProjectWorkspaceRepository projectRepo) {
        this.sprintRepo = sprintRepo;
        this.projectRepo = projectRepo;
    }

    @GetMapping
    public List<Sprint> listAll(@RequestParam(required = false) Long projectId) {
        List<Sprint> all = sprintRepo.findAll();
        if (projectId == null) return all;

        return all.stream()
                .filter(s -> s.getProject() != null && projectId.equals(s.getProject().getId()))
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public Sprint getById(@PathVariable Long id) {
        return sprintRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Sprint not found: " + id));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Sprint create(@Valid @RequestBody SprintRequest req) {
        ProjectWorkspace project = projectRepo.findById(req.projectId())
                .orElseThrow(() -> new ResourceNotFoundException("ProjectWorkspace not found: " + req.projectId()));

        Sprint s = new Sprint();
        s.setName(req.name());
        s.setStartDate(req.startDate());
        s.setEndDate(req.endDate());
        s.setProject(project);

        return sprintRepo.save(s);
    }

    @PutMapping("/{id}")
    public Sprint update(@PathVariable Long id, @Valid @RequestBody SprintRequest req) {
        Sprint s = getById(id);

        ProjectWorkspace project = projectRepo.findById(req.projectId())
                .orElseThrow(() -> new ResourceNotFoundException("ProjectWorkspace not found: " + req.projectId()));

        s.setName(req.name());
        s.setStartDate(req.startDate());
        s.setEndDate(req.endDate());
        s.setProject(project);

        return sprintRepo.save(s);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        sprintRepo.delete(getById(id));
    }
}
