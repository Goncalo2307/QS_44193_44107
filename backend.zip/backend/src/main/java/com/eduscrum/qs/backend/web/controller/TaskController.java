package com.eduscrum.qs.backend.web.controller;

import com.eduscrum.qs.backend.domain.enums.TaskStatus;
import com.eduscrum.qs.backend.domain.model.Sprint;
import com.eduscrum.qs.backend.domain.model.Task;
import com.eduscrum.qs.backend.exception.ResourceNotFoundException;
import com.eduscrum.qs.backend.repository.SprintRepository;
import com.eduscrum.qs.backend.repository.TaskRepository;
import com.eduscrum.qs.backend.web.dto.request.TaskRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskRepository taskRepo;
    private final SprintRepository sprintRepo;

    public TaskController(TaskRepository taskRepo, SprintRepository sprintRepo) {
        this.taskRepo = taskRepo;
        this.sprintRepo = sprintRepo;
    }

    @GetMapping
    public List<Task> listAll(@RequestParam(required = false) Long sprintId) {
        List<Task> all = taskRepo.findAll();
        if (sprintId == null) return all;

        return all.stream()
                .filter(t -> t.getSprint() != null && sprintId.equals(t.getSprint().getId()))
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public Task getById(@PathVariable Long id) {
        return taskRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found: " + id));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Task create(@Valid @RequestBody TaskRequest req) {
        Sprint sprint = sprintRepo.findById(req.sprintId())
                .orElseThrow(() -> new ResourceNotFoundException("Sprint not found: " + req.sprintId()));

        Task t = new Task();
        t.setTitle(req.title());
        t.setDescription(req.description());
        t.setStatus(req.status() == null ? TaskStatus.TO_DO : req.status());
        t.setSprint(sprint);

        return taskRepo.save(t);
    }

    @PutMapping("/{id}")
    public Task update(@PathVariable Long id, @Valid @RequestBody TaskRequest req) {
        Task t = getById(id);

        Sprint sprint = sprintRepo.findById(req.sprintId())
                .orElseThrow(() -> new ResourceNotFoundException("Sprint not found: " + req.sprintId()));

        t.setTitle(req.title());
        t.setDescription(req.description());
        if (req.status() != null) t.setStatus(req.status());
        t.setSprint(sprint);

        return taskRepo.save(t);
    }

    @PatchMapping("/{id}/status")
    public Task updateStatus(@PathVariable Long id, @RequestParam TaskStatus status) {
        Task t = getById(id);
        t.setStatus(status);
        return taskRepo.save(t);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        taskRepo.delete(getById(id));
    }
}
