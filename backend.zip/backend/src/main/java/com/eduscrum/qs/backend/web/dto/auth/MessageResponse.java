package com.eduscrum.qs.backend.web.dto.auth;

public record MessageResponse(String message) {}
