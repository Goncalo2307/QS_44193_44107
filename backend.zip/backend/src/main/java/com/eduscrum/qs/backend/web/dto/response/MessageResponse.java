package com.eduscrum.qs.backend.web.dto.response;

public record MessageResponse(String message) {}
