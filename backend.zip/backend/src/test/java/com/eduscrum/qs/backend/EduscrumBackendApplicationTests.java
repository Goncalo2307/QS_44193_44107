package com.eduscrum.qs.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduscrumBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
